Dear marker

Our project consist of two distinct parts:
1) the actual project aka EPIC(Eavesdropping Protection in Conclave)
2) the proof of concept project aka Malware or Eavesdrop

Because the parts are so distint we have decided to give them separate documentation.

It should be note that the Malware part is not the main focus of the project. 